package com.example.demo;

import java.util.List;

public class userDaoImpl implements userDao {

	@Override
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserById(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(String userId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public User createUser(String userID, String userFullName, String password, String role) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
